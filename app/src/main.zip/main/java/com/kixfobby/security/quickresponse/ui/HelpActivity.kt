package com.kixfobby.security.quickresponse.ui

import android.os.Bundle
import com.kixfobby.security.quickresponse.BaseActivity
import com.kixfobby.security.quickresponse.R

class HelpActivity : BaseActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
    }

}
