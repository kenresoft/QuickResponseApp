package com.kixfobby.security.quickresponse.storage

enum class Admin(s: String) {
    A("amadikenneth8@gmail.com")

}