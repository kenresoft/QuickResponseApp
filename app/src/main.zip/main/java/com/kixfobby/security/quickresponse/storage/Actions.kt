package com.kixfobby.security.quickresponse.storage;

enum class Actions {
    START,
    STOP
}
