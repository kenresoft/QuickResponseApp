package com.kixfobby.security.quickresponse.room.repository

import androidx.lifecycle.LiveData
import com.kixfobby.security.quickresponse.room.dao.ContactDao
import com.kixfobby.security.quickresponse.room.entity.ContactDetails

class ContactRepository(private var contactDao: ContactDao) {
    val getAllContacts: LiveData<List<ContactDetails>> = contactDao.getAllContactsDao()

    suspend fun addContact(contactDetails: ContactDetails) {
        contactDao.insertContact(contactDetails)
    }

    suspend fun deleteContact(contactName: String, contactNumber: String) {
        contactDao.deleteContact(contactName, contactNumber)
    }

    suspend fun deleteAllContacts(contactDetails: ContactDetails) {
        contactDao.deleteAllContacts(contactDetails)
    }

    suspend fun isContactExists(contactName: String, contactNumber: String): Boolean =
        contactDao.isContactExists(contactName, contactNumber)

}