package com.kixfobby.security.quickresponse.model

data class DashItem(var image: Int, var title: String, var badge: Int)