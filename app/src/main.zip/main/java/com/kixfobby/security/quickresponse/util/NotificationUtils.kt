package com.kixfobby.security.quickresponse.util

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import androidx.core.app.NotificationCompat

import com.kixfobby.security.quickresponse.R
import com.kixfobby.security.quickresponse.ui.MainActivity

// TODO: Step 1.1 extension function to send messages (GIVEN)

// TODO: Step 1.14 Cancel all notifications
