package com.kixfobby.security.quickresponse.model

import android.net.Uri

class VideoModel {
    var videoTitle: String? = null
    var videoDuration: String? = null
    var videoUri: Uri? = null
}