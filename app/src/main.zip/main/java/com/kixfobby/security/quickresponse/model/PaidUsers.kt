package com.kixfobby.security.quickresponse.model

data class PaidUsers(
    var email: String? = null,
    var phone: String? = null,
    var date: String? = null,
) {
}