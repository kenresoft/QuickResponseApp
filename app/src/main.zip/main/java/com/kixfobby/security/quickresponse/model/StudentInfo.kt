package com.kixfobby.security.quickresponse.model

data class StudentInfo(
    var studentList: ArrayList<String> = arrayListOf()
)
