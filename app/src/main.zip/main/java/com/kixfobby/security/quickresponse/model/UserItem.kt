package com.kixfobby.security.quickresponse.model

data class UserItem(
    var email: String = ""
)


/*
fun toMap(): Map<String, Any> {
    val student = HashMap<String, Any>()
    student["name"] = name
    student["age"] = studentItem.name
    student["address"] = studentItem.address
    student["mobile_no"] = studentItem.mobile_no
    return student
}*/
